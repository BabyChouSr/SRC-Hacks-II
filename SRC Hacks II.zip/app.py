from flask import Flask, render_template, request,redirect,flash,url_for,send_from_directory, jsonify
from forms import RegistrationForm, LoginForm
from werkzeug.exceptions import HTTPException
from google.cloud import vision
import pandas as pd
import numpy as np
import os
import io
import unidecode


app = Flask(__name__)

app.config['SECRET_KEY'] = 'd78c756a9b3d38607f443ba43cf1ebf9'
APP_ROOT = os.path.dirname(os.path.abspath(__file__))

@app.route('/', methods = ["GET", "POST"])
def blank():
    filename = ""
    target = os.path.join(APP_ROOT, 'static/')
    print(target)
    if not os.path.isdir(target):
        os.mkdir(target)
    else:
        print("Couldn't create upload directory: {}".format(target))
    print(request.files.getlist("file"))
    for upload in request.files.getlist("file"):
        print(upload)
        print("{} is the file name".format(upload.filename))
        filename = upload.filename
        destination = "/".join([target, ""])
        print("Accept Incoming file:",filename)
        print("Save it to: ",destination)
        upload.save(destination)
    #return send_from_directory("static", "temp.jpg", as_attachment=True)
    return render_template("index.html", image_name = filename)

@app.route('/complete.html', methods = ["GET", "POST"])
def complete():
    f = "C:/Users/HP/Desktop/SRC Hacks II/static/temp2.png"
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "/Users/HP/Desktop/SRC Hacks II/crafty-sound-269020-e21f06b578fe.json"
    client = vision.ImageAnnotatorClient()
    with io.open(f , 'rb') as image:
        content = image.read()

    image = vision.types.Image(content=content)
    response = client.text_detection(image=image)
    texts = response.text_annotations

    x = []
    for text in texts:
        x.append(text.description)
        break

    y = str(x[0])
    y = y.replace("\n", ",")
    y = y.replace("(", ",")
    y = y.replace(")", "")
    arr = y.split(",")
    allergies = ["Cows's Milk", "Eggs", "Nuts", "Peanuts", "Shellfish", "Wheat", "Soy", "Fish","Wheat","Cheddar",
                 "Cheese","Whipping Cream", "Sour Cream", "Egg", "Butter", "monosodium glutamate", "mayonnaise"]
    all2 = []
    for o in allergies:
        all2.append(o.lower())
    df = pd.read_csv('static/foods.csv')
    pot = []
    dict = {}
    arr2 = []
    for z in arr: #decode the accent thing
        arr2.append(unidecode.unidecode(z.lower()))
    key = []
    value = []
    for i in arr2: # new array foods
        #print(i)
        print(i)
        for j in df.columns: # traverse dataset
            pot = []
            if i in j: # if the food is in dataset
                #print("Name of the dish:"+i)
                #print(df[j].values.tolist())

                #for k in all2: # if the ingredient is in allergies
                    #print(z)
                    #print(df[j].values.tolist())
                    #if k in df[j].values.tolist():
                thing = df.columns.get_loc(j)
                key.append(i)
                if len(i) != 0:
                    value.append(df.iloc[thing].tolist())
    key = list(filter(None, key))
    key = list(set(key))
    #value = [x for x in value if x != []]
    print(key)
    print(value)
    l = len(key)
    #return send_from_directory("static", "temp.jpg", as_attachment=True)
    return render_template("complete.html", key = key , value = value, length = l)

'''
@app.route('/filesender/<filename>', methods = ['GET', 'POST'])
def send_image(filename):
    return send_from_directory("images", filename)
'''


@app.route('/register.html', methods = ['GET', 'POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        flash(f'Account created for {form.username.data}!', 'success')
        return redirect(url_for('home'))
    return render_template('register.html',title = 'Register', form = form)


@app.route('/login.html', methods = ['GET','POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        if form.email.data == 'admin@blog.com' and form.password.data == 'password':
            flash('You have been logged in!', 'success')
            return redirect(url_for('home'))
        else:
            flash('Login Unsuccessful. Please check username and password' , 'danger')
    return render_template('login.html',title = 'Login', form = form)
