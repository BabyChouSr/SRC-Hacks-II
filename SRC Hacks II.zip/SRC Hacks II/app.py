from flask import Flask, render_template, request,redirect,flash,url_for,send_from_directory, jsonify
from flask_sqlalchemy import SQLAlchemy
from forms import RegistrationForm, LoginForm
from werkzeug.exceptions import HTTPException
from google.cloud import vision
import pandas as pd
import numpy as np
import os
import io
import unidecode
import math

app = Flask(__name__)

app.config['SECRET_KEY'] = 'd78c756a9b3d38607f443ba43cf1ebf9'

URLS = []
cancer_l = []
diabetes_l = []
asthma_1 = []
heart_1 = []
inconclusive_1 = []
testing_1 = []
risk_1 = []
stomach_1 = []
liver_l = []
totalPrint = []

'''
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key = False)
    username = db.Column(db.String(20), unique = False, nullable = False)
    email = db.Column(db.String(120), unique = False, nullable = False)
    #image_file =  db.Column(db.String(20), unique = False, nullable = False, default = "default.jpg")
    password = db.Column(db.String(60), nullable = False)
    allergies = db.Column(db.String(200), unique=False, nullable = False)

    def __repr__(self):
        return f"User('{self.username}', '{self.email}')"
'''


APP_ROOT = os.path.dirname(os.path.abspath(__file__))

@app.route('/', methods = ["GET", "POST"])
def blank():
    filename = ""
    target = os.path.join(APP_ROOT, 'static/')
    print(target)
    if not os.path.isdir(target):
        os.mkdir(target)
    else:
        print("Couldn't create upload directory: {}".format(target))
    print(request.files.getlist("file"))
    for upload in request.files.getlist("file"):
        print(upload)
        print("{} is the file name".format(upload.filename))
        filename = upload.filename
        destination = "/".join([target, ""])
        print("Accept Incoming file:",filename)
        print("Save it to: ",destination)
        upload.save(destination)
    #return send_from_directory("static", "temp.jpg", as_attachment=True)
    return render_template("index.html", image_name = filename)

@app.route('/index.html', methods = ["GET", "POST"])
def home():
    filename = ""
    target = os.path.join(APP_ROOT, 'static/')
    print(target)
    if not os.path.isdir(target):
        os.mkdir(target)
    else:
        print("Couldn't create upload directory: {}".format(target))
    print(request.files.getlist("file"))
    for upload in request.files.getlist("file"):
        print(upload)
        print("{} is the file name".format(upload.filename))
        filename = upload.filename
        destination = "/".join([target, ""])
        print("Accept Incoming file:",filename)
        print("Save it to: ",destination)
        upload.save(destination)
    #return send_from_directory("static", "temp.jpg", as_attachment=True)
    return render_template("index.html", image_name = filename)
@app.route('/complete.html', methods = ["GET", "POST"])
def complete():
    f = "C:/Users/HP/Desktop/SRC Hacks II/static/temp2.png"
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "/Users/HP/Desktop/SRC Hacks II/crafty-sound-269020-e21f06b578fe.json"
    client = vision.ImageAnnotatorClient()
    with io.open(f , 'rb') as image:
        content = image.read()

    image = vision.types.Image(content=content)
    response = client.text_detection(image=image)
    texts = response.text_annotations

    x = []
    for text in texts:
        x.append(text.description)
        break

    y = str(x[0])
    y = y.replace("\n", ",")
    y = y.replace("(", ",")
    y = y.replace(")", "")
    arr = y.split(",")
    allergies = ["Cows's Milk", "Eggs", "Nuts", "Peanuts", "Shellfish", "Wheat", "Soy", "Fish","Wheat","Cheddar",
                 "Cheese","Whipping Cream", "Sour Cream", "Egg", "Butter", "monosodium glutamate", "mayonnaise"]
    all2 = []
    for o in allergies:
        all2.append(o.lower())
    df = pd.read_csv('static/foods.csv')
    pot = []
    dict = {}
    arr2 = []

    for z in arr: #decode the accent thing
        arr2.append(unidecode.unidecode(z.lower()))
    if "ramen noodles" in arr2:
        arr2.clear()
        arr2.append("tung-i ramen")
    key = []
    value = []
    for i in arr2: # new array foods
        #print(i)
        print(i)
        for j in df.columns: # traverse dataset
            pot = []
            if i in j: # if the food is in dataset
                #print("Name of the dish:"+i)
                #print(df[j].values.tolist())

                #for k in all2: # if the ingredient is in allergies
                    #print(z)
                    #print(df[j].values.tolist())
                    #if k in df[j].values.tolist():
                print("I AM AT: "+j)
                thing = df.columns.get_loc(j)
                key.append(i)
                if len(i) != 0:
                    #value.append(df[thing].values.toList())
                    value.append(df.iloc[thing].tolist())
    key = list(filter(None, key))
    key = list(set(key))

    #value = [x for x in value if x != []]
    print(key)  # corresponding ingredients that cause cancer
    print(value) # all the ingredients
    l = len(key)


    # THE CLASSIFICATION PART
    df2 = pd.read_csv("static/carcinogen.csv")
    cause = []
    cancer = np.asanyarray(df2['cancer'].str.lower())
    diabetes = np.asanyarray(df2['diabetes'].str.lower())
    asthma = np.asanyarray(df2['asthma'].str.lower())
    heart = np.asanyarray(df2['Heart'].str.lower())
    stomach = np.asanyarray(df2['stomach'].str.lower())
    liver = np.asanyarray(df2['LIVER'].str.lower())


    cancerc = []
    diabetesc = []
    asthmac = []
    heartc = []
    stomachc = []
    liverc = []
    print('sup')
    for b in cancer:
        for w1 in value:
            for t1 in w1:
                if t1 == b:
                    cancerc.append(t1)
    for c in diabetes:
        for w2 in value:
            for t2 in w2:
                if t2 == c:
                    diabetesc.append(t2)
    for d in asthma:
        for w3 in value:
            for t3 in w3:
                if t3 == d:
                    asthmac.append(t3)
    for e in stomach:
        for w4 in value:
            for t4 in w4:
                if t4 == e:
                    stomachc.append(t4)
    for g in heart:
        for w6 in value:
            for t6 in w6:
                if t6 == g:
                    heartc.append(t6)
    for f in liver:
        for w5 in value:
            for t5 in w5:
                if t5 == f:
                    liverc.append(t5)
    liverc = list(set(liverc))
    asthmac = list(set(asthmac))
    diabetesc = list(set(diabetesc))
    heartc = list(set(heartc))
    cancerc = list(set(cancerc))
    stomachc = list(set(stomachc))

    if len(liverc) == 0:
        liverc = ["There are no carcinogen causing ingredients."]
    if len(stomachc) == 0:
        stomachc = ["There are no carcinogen causing ingredients."]
    if len(heartc) == 0:
        heartc = ["There are no carcinogen causing ingredients."]
    if len(asthmac) == 0:
        asthmac = ["There are no carcinogen causing ingredients."]
    if len(cancerc) == 0:
        cancerc = ["There are no carcinogen causing ingredients."]
    if len(diabetesc) == 0:
        diabetesc = ["There are no carcinogen causing ingredients."]



    # = [x for x in cause if str(x) != 'nan']
    #cause = list(set(cause))
    #if len(cause) == 0:
        #cause = ["No Carcinogens"]
    #return send_from_directory("static", "temp.jpg", as_attachment=True)

    return render_template("complete.html", key = key , value = value, length = l,
                           cancer = cancerc, asthma= asthmac, diabetes = diabetesc, stomach = stomachc, liver= liverc
                           , heart = heartc)

'''
@app.route('/filesender/<filename>', methods = ['GET', 'POST'])
def send_image(filename):
    return send_from_directory("images", filename)
'''
@app.route('/profile.html')
def profile():
    allergies = ["wheat flour", "egg","monosodium glutamate","sour cream"]
    return render_template('profile.html', allergies = allergies)

@app.route('/register.html', methods = ['GET', 'POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        flash(f'Account created for {form.username.data}!', 'success')
        return redirect(url_for('login'))
    return render_template('register.html',title = 'Register', form = form)


@app.route('/login.html', methods = ['GET','POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        if form.email.data == 'admin@blog.com' and form.password.data == 'password':
            flash('You have been logged in!', 'success')
            return redirect(url_for('profile'))
        else:
            flash('Login Unsuccessful. Please check username and password' , 'danger')
    return render_template('login.html',title = 'Login', form = form)
